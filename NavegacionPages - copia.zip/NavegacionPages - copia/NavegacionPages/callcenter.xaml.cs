namespace NavegacionPages;

public partial class callcenter : ContentPage
{
	public callcenter()
	{
		InitializeComponent();
	}
}
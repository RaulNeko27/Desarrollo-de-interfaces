﻿namespace NavegacionPages
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnDetailsButtonClicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("detailspage");
        }
    }

}

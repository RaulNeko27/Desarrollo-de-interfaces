﻿namespace NavegacionPages
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute("detailspage", typeof(DetailsPage));
        }
    }
}

namespace NavegacionPages;

public partial class licencia : ContentPage
{
	public licencia()
	{
		InitializeComponent();
	}
}